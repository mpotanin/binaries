# import osgeo.osr as a convenience
from osgeo.gdal import deprecation_warn
deprecation_warn('osr')

from osgeo.osr import *
